//
//  HomeHeaderCell.swift
//  MovementCohort1
//
//  Created by Zachary Farmer on 2/12/23.
//

import UIKit

class HomeHeaderCell: UICollectionViewCell {
    static let kind = String(describing: HomeHeaderCell.self)
    static let reuseIdentifer = String(describing: HomeHeaderCell.self)
    static let nib = UINib(nibName: String(describing: HomeHeaderCell.self), bundle: nil)

    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
//    func configure(with scroller: Item) {
//        dump(scroller)
//    }
//
}
