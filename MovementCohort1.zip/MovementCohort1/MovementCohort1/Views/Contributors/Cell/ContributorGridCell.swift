import UIKit

class ContributorGridCell: UICollectionViewCell {
    static let kind = String(describing: ContributorGridCell.self)
    static let reuseIdentifier = String(describing: ContributorGridCell.self)
    static let nib = UINib(nibName: String(describing: ContributorGridCell.self), bundle: nil)
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
